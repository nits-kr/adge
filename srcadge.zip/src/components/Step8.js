import React from 'react'

function Step8() {
  return (
    <>
     <div id="" className="">
        <div className="pagetitle">
          <h2>Data Integration and Interoperability</h2>
        </div>
        <div className="QuestionsStrip"></div>
      </div> 
    </>
  )
}

export default Step8
