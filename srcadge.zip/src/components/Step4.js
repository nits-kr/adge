import React from 'react'

function Step4() {
  return (
    <>
     <div id="" className="">
        <div className="pagetitle">
          <h2>Data Modelling and Design</h2>
        </div>
        <div className="QuestionsStrip"></div>
      </div> 
    </>
  )
}

export default Step4
