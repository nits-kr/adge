import React from 'react'

function Step6() {
  return (
    <>
     <div id="" className="">
        <div className="pagetitle">
          <h2>Data Security and Privacy</h2>
        </div>
        <div className="QuestionsStrip"></div>
      </div> 
    </>
  )
}

export default Step6
