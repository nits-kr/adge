import React from 'react'

function Step9() {
  return (
    <>
     <div id="" className="">
        <div className="pagetitle">
          <h2>Open Data</h2>
        </div>
        <div className="QuestionsStrip"></div>
      </div> 
    </>
  )
}

export default Step9
