import React from 'react'

function Step3() {
  return (
    <>
     <div id="" className="">
        <div className="pagetitle">
          <h2>Data Catalogue</h2>
        </div>
        <div className="QuestionsStrip"></div>
      </div> 
    </>
  )
}

export default Step3
