import React from 'react'

function Step5() {
  return (
    <>
     <div id="" className="">
        <div className="pagetitle">
          <h2>Data Architecture</h2>
        </div>
        <div className="QuestionsStrip"></div>
      </div> 
    </>
  )
}

export default Step5
