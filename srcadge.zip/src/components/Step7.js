import React from 'react'

function Step7() {
  return (
    <>
     <div id="" className="">
        <div className="pagetitle">
          <h2>Data Storage</h2>
        </div>
        <div className="QuestionsStrip"></div>
      </div> 
    </>
  )
}

export default Step7
